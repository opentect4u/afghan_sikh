@extends('common.master')
@section('content')

<!-- ======= Contact Section ======= -->
<section id="contact" class="contact">
    <div class="container">
        <div class="section-title">
            <h2 data-aos="fade-up">Gurudwara Dashboard</h2>
            <!-- <p data-aos="fade-up">Magnam dolores commodi suscipit. Necessitatibus eius consequatur ex aliquid fuga eum quidem. Sit sint consectetur velit.  -->
            </p>
        </div>
    </div>
</section>
<!-- End Contact Section -->


@endsection