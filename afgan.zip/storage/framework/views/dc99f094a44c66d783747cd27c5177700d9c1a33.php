<!-- ======= Breadcrumbs ======= -->
<section id="breadcrumbs" class="breadcrumbs">
  <div class="container">
    <ol>
      <li><a href="<?php echo e(route('index')); ?>">Home</a></li>
      <li>Apply Now</li>
    </ol>
    <h2>Apply Now</h2>
  </div>
</section>
<!-- End Breadcrumbs -->
<?php /**PATH /var/www/html/afgan_shik/resources/views/common/breadcrumbs.blade.php ENDPATH**/ ?>