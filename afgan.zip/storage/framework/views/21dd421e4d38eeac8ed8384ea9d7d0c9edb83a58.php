<header id="header">
    <div class="container d-flex">

      <div class="logo mr-auto">
        <h1 class="text-light"><a href="<?php echo e(route('index')); ?>"><span>Afghan Sikh Helps Line</span></a></h1>
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href="index.html"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->
      </div>

      <nav class="nav-menu d-none d-lg-block">
        <ul>
          <li class="active"><a href="<?php echo e(route('index')); ?>">Home</a></li>
          <li><a href="<?php echo e(route('index')); ?>#about">About</a></li>
          <li><a href="<?php echo e(route('index')); ?>#services">Services</a></li>
          <li><a href="<?php echo e(route('index')); ?>#contact">Contact</a></li>

        </ul>
      </nav><!-- .nav-menu -->

    </div>
  </header><?php /**PATH /var/www/html/afgan_shik/resources/views/common/header.blade.php ENDPATH**/ ?>