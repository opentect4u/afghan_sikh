<?php $__env->startSection('content'); ?>

<!-- ======= Contact Section ======= -->
<section id="contact" class="contact">
    <div class="container">
        <div class="section-title">
            <h2 data-aos="fade-up">Gurudwara Dashboard</h2>
            <!-- <p data-aos="fade-up">Magnam dolores commodi suscipit. Necessitatibus eius consequatur ex aliquid fuga eum quidem. Sit sint consectetur velit.  -->
            </p>
        </div>
    </div>
</section>
<!-- End Contact Section -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('common.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/afgan_shik/resources/views/gurudwara/dashboard.blade.php ENDPATH**/ ?>